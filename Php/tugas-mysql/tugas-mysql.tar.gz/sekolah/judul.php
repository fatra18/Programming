<center><h2>TOKO</h2></center>
		<hr>
